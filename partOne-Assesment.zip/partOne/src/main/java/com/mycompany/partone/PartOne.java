/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.partone;

import static com.mycompany.partone.PartOne.User.registerUser;
import java.util.Scanner; //this is used to get user input
import java.util.ArrayList; //for storing users data
import java.util.regex.Pattern; //for validating the number phone,username and password


/**
 *
 * @author RC_Student_lab
 */
public class PartOne {
    //this is used to get user input from the keyboard 
    static Scanner scanner= new Scanner(System.in);
    //for storing registered users
    static ArrayList<User>users=new ArrayList<>();
    // this will store the login status message after the user loggedin
    static String loginStatusMessage="";
    
    //the first method to run
 public static void main(String[] args) {  

    String regResult = registerUser();
     // print out the registration message
    System.out.println(regResult);
    //call the loginUser method for user to login        

    boolean loggedin = logInUser();
    //show the login result using loginreturnstatus method
    System.out.println(returnLogInStatus(loggedin));
 }

   private static boolean logInUser() {
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        return false;
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
   }

    private static boolean returnLogInStatus(boolean loggedin) {
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        return false;
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
// the class to store user information such as phone number , user's name and password
 static class User{
     String firstName;
     String lastName;
     String userName;
     User(String firstName,String lastName,String phoneNumber,String userName,String password){
     this.firstName = firstName;
     this.lastName = lastName;
     this.userName = userName;
     
     }
//this method checks if the username has an underscore with five character or less
     public static boolean checkUserName(String userName){
     if(userName.contains("-")){
     if(userName.length()<=5){
     return true;
     }else{
     return false;
     }        
     }
         return false;
     
     }
//this is to check if the password is weak or strong
 public static boolean checkPasswordComplexity(String password){
     //password must have capital letters,special character,numbers and must have 8 characters or long
  String regex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$";
return Pattern.matches(regex, password);

 }
 //to validate phone number 
 public static boolean isValidSouthAfricanPhoneNumber(String phoneNumber){
 String regex = "^\\+27\\d{9}$"; //+27 followed by 9 digits 
 return Pattern.matches(regex, phoneNumber);
}
 //to handle registration process for new user
 public static String registerUser() {
    System.out.print("Enter first name: ");
    String firstName = scanner.nextLine();
    System.out.print("Enter last name: ");
    String lastName = scanner.nextLine();
    System.out.print("Enter phone number: ");
    String phoneNumber = scanner.nextLine();
    System.out.print("Enter username: ");
    String userName = scanner.nextLine();
    System.out.print("Enter password: ");
    String password = scanner.nextLine();

    if (User.checkUserName(userName)) {
        return "Username is not correctly formatted.";
    }

    if (!User.checkPasswordComplexity(password)) {
        return "Password is not correctly formatted.";
    }

    users.add(new User(firstName, lastName, phoneNumber, userName, password));
    return "User registered successfully!";
}

        private Object getUserName() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private Object getPassword() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private String getFirstName() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private String getLastName() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }


public class PasswordValidator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String password = "";
        boolean validPassword = false;

        while (validPassword==false) {
            System.out.print("Enter password: ");
            password = scanner.nextLine();
            validPassword = checkPasswordComplexity(password);

            if (validPassword==false) {
                System.out.println("Please enter a password in the correct format. It must contain at least eight characters, a capital letter, and a number.");
            } else {
                System.out.println("Successfully captured password.");
            }
        }
    }

    public static boolean checkPasswordComplexity(String password) {
        // complexity check: at minimum of  8 characters, uppercase ,lowercase and numbers
        return password.length() >= 8 &&
               password.matches(".*[A-Z].*") &&
               password.matches(".*\\d.*");
    }
}

 }
 
//loop to keep asking user to put correct phonenumber
 public class PhoneNumberValidator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String phoneNumber = "";
        boolean validPhoneNumber = false;

        while (!validPhoneNumber) {
            System.out.print("Enter phone number (+27xxxxxxxxx): ");
            phoneNumber = scanner.nextLine();
            validPhoneNumber = isValidSouthAfricanPhoneNumber(phoneNumber);

            if (!validPhoneNumber) {
                System.out.println("Please enter the phone number in the correct format. It must start with +27 and contain 11 digits in total.");
            } else {
                System.out.println("Successfully captured phone number.");
            }
        }
    }

    public static boolean isValidSouthAfricanPhoneNumber(String phoneNumber) {
        // Basic check: starts with +27 and followed by 9 digits
        return phoneNumber.matches("\\+27\\d{9}");
    }
}


public class UserSystem {
    static ArrayList<User> users = new ArrayList<>();
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        

// new user registration
                loginUser();
    }

        private static void loginUser() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

   public void logInUser(String username, String password) {
    if (username.equals("") && password.equals("")) {
        System.out.println("Login successful!");
    } else {
        System.out.println("Invalid credentials.");
    }
}

            }
        

  

class userAccount {
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String userName;
    private String password;

    public userAccount(String firstName, String lastName, String phoneNumber, String userName, String password) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.userName = userName;
        this.password = password;
    }

    }

  
  
}


 
  
 
